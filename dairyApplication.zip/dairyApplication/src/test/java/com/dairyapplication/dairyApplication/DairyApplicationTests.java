package com.dairyapplication.dairyApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DairyApplicationTests {

	@Test
	void contextLoads() {
	}

}
